from setuptools import setup

setup(

     name="paquetecalculos",
     version="1.0",
     description="paquete de redonde y potencia",
     author="Daniela Ramirez",
     author_email="daniela@hotmail.com",
     url="www.tecnologia:com",
     packages=["calculos", "calculos.redondeo_potencia"]

	)
