def potencia(base, exponente):
	print("el resultado es", base**exponente)

def redondear(numero):
	print("el resultado es_::", round(numero))