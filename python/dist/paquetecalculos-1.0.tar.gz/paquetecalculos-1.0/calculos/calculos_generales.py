def  suma(op1, op2):
	print("la suma del total es ", op1+op2)

def  resta(op1, op2):
	print("la resta del total es ", op1-op2)

def  multiplicar(op1, op2):
	print("el resultado del total es ", op1*op2)

def potencia(base, exponente):
	print("el resultado es", base**exponente)

def redondear(numero):
	print("el resultado es_::", round(numero))